#ifndef l_ooc_h
#define l_ooc_h

static void create();
mixed can_ooc();
mixed can_ooc_to_liv(object ob);
mixed can_ooc_to_liv_str(object ob, string str);
mixed can_ooc_str(string str);
mixed do_ooc();
mixed do_ooc_to_liv(object ob);
mixed do_ooc_to_liv_str(object ob, string str);
mixed do_ooc_str(string str);
string GetHelp(string str);

#endif /* l_ooc_h */
