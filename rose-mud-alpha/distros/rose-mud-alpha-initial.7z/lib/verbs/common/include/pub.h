#ifndef l_pub_h
#define l_pub_h

static void create();
mixed can_pub();
mixed can_pub_str();
mixed do_pub();
mixed do_pub_str(string str);

#endif /* l_pub_h */
